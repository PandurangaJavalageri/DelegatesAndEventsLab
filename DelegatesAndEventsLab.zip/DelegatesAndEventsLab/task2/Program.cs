﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    public delegate void buttonclicked();
    internal class Program
    {
        static void Main(string[] args)
        {
            Form f = new Form();
            f.button = new Button();
            f.eventHandler();
            

        }
    }
    public class Button
    {
        public event buttonclicked bd = null;
        public void click()
        {
            bd();
            
            Console.WriteLine("clicked successfully");
        }
    }
    public class Form
    {
        public Button button;
        public void SubscribedTobtnLock()
        {
            button.bd += () =>
            {
                Console.WriteLine("hello");
            };
           
        }

        public void eventHandler()
        {
            SubscribedTobtnLock();
           button.click();
        }
    }

}
