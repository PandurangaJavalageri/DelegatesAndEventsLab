﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAndEventsLab
{
    public delegate string StringModifier (string s);
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a string");
            string s=Console.ReadLine();
            StringModifier st = UpperCase;
            StringModifier st2 = Reverse;
            StringModifier st3 = st + st2;
    
            string ans = st2(st(s));
            Console.WriteLine(ans);





        }
        public static string UpperCase(string s)
        {
            return s.ToUpper();
        }
        public static string LowerCase(string s)
        {
            return s.ToLower();
        }
        public static string Reverse(string s)
        {
            return new string(s.Reverse().ToArray());
        }
    }
    
}
